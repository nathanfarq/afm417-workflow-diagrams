import { useState } from 'react';
import { FileText } from 'lucide-react';

interface InputPanelProps {
  onGenerate: (title: string, narrative: string) => void;
  isGenerating: boolean;
}

export function InputPanel({ onGenerate, isGenerating }: InputPanelProps) {
  const [title, setTitle] = useState('');
  const [narrative, setNarrative] = useState('');

  const handleGenerate = () => {
    if (title.trim() && narrative.trim()) {
      onGenerate(title, narrative);
    }
  };

  const loadSampleData = () => {
    setTitle('Invoice Processing Workflow');
    setNarrative(
      'The Accounts Payable department receives invoices from vendors via email. ' +
      'The AP clerk enters invoice data into the system and requires approval from the finance manager. ' +
      'The finance manager reviews the invoice against the purchase order and approves or rejects the transaction. ' +
      'If approved, the system performs automated validation checks to ensure the invoice amount matches the purchase order. ' +
      'The Treasury department processes the payment after receiving approval. ' +
      'The payment is released only after dual authorization from two authorized signatories. ' +
      'The Accounting department performs monthly reconciliation of all processed invoices. ' +
      'No segregation of duties exists between invoice entry and payment processing. ' +
      'The AP clerk manually enters data without review.'
    );
  };

  return (
    <div className="w-full max-w-md bg-white rounded-xl shadow-lg p-6 space-y-6">
      <div className="flex items-center gap-3 pb-4 border-b border-gray-200">
        <FileText className="w-6 h-6 text-blue-600" />
        <h2 className="text-xl font-semibold text-gray-900">Process Input</h2>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Process Title
          </label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g., Revenue Recognition Process"
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Client Narrative
          </label>
          <textarea
            value={narrative}
            onChange={(e) => setNarrative(e.target.value)}
            placeholder="Provide detail about the client's process narrative here. Describe the sequence of activities, departments involved, and any existing controls..."
            rows={12}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition resize-none"
          />
        </div>

        <div className="flex gap-3">
          <button
            onClick={handleGenerate}
            disabled={isGenerating || !title.trim() || !narrative.trim()}
            className="flex-1 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed text-white font-medium py-3 px-6 rounded-lg transition shadow-md hover:shadow-lg"
          >
            {isGenerating ? 'Generating...' : 'Create Flow Chart'}
          </button>

          <button
            onClick={loadSampleData}
            className="px-4 py-3 border-2 border-gray-300 hover:border-gray-400 text-gray-700 font-medium rounded-lg transition"
            title="Load sample data"
          >
            Sample
          </button>
        </div>

        <p className="text-xs text-gray-500 mt-2">
          Enter a process narrative describing the workflow, departments, controls, and activities. The system will automatically identify control points and potential weaknesses.
        </p>
      </div>
    </div>
  );
}
