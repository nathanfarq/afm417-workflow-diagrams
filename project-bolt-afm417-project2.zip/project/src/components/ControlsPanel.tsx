import { useState } from 'react';
import { Shield, ChevronDown, ChevronRight } from 'lucide-react';
import { Control } from '../utils/narrativeParser';

interface ControlsPanelProps {
  controls: Control[];
}

export function ControlsPanel({ controls }: ControlsPanelProps) {
  const [isExpanded, setIsExpanded] = useState(true);
  const [visibleControls, setVisibleControls] = useState<Set<string>>(
    new Set(controls.map(c => c.id))
  );

  const toggleControl = (id: string) => {
    const newVisible = new Set(visibleControls);
    if (newVisible.has(id)) {
      newVisible.delete(id);
    } else {
      newVisible.add(id);
    }
    setVisibleControls(newVisible);
  };

  const controlsByType = controls.reduce((acc, control) => {
    if (!acc[control.type]) {
      acc[control.type] = [];
    }
    acc[control.type].push(control);
    return acc;
  }, {} as Record<string, Control[]>);

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-center justify-between p-4 bg-blue-50 hover:bg-blue-100 transition"
      >
        <div className="flex items-center gap-3">
          <Shield className="w-5 h-5 text-blue-600" />
          <h3 className="font-semibold text-gray-900">
            Identified Controls ({controls.length})
          </h3>
        </div>
        {isExpanded ? (
          <ChevronDown className="w-5 h-5 text-gray-600" />
        ) : (
          <ChevronRight className="w-5 h-5 text-gray-600" />
        )}
      </button>

      {isExpanded && (
        <div className="p-4 space-y-4 max-h-96 overflow-y-auto">
          {controls.length === 0 ? (
            <p className="text-sm text-gray-500 text-center py-4">
              No controls identified yet
            </p>
          ) : (
            Object.entries(controlsByType).map(([type, typeControls]) => (
              <div key={type} className="space-y-2">
                <h4 className="text-sm font-semibold text-gray-700 uppercase tracking-wide">
                  {type}
                </h4>
                {typeControls.map((control) => (
                  <div
                    key={control.id}
                    className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg border border-blue-200"
                  >
                    <input
                      type="checkbox"
                      checked={visibleControls.has(control.id)}
                      onChange={() => toggleControl(control.id)}
                      className="mt-1 w-4 h-4 text-blue-600 rounded focus:ring-2 focus:ring-blue-500"
                    />
                    <div className="flex-1">
                      <p className="text-sm text-gray-800">{control.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}
