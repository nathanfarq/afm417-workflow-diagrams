import { useState } from 'react';
import { AlertTriangle, ChevronDown, ChevronRight } from 'lucide-react';
import { Weakness } from '../utils/narrativeParser';

interface WeaknessesPanelProps {
  weaknesses: Weakness[];
}

export function WeaknessesPanel({ weaknesses }: WeaknessesPanelProps) {
  const [isExpanded, setIsExpanded] = useState(true);

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high':
        return 'bg-red-50 border-red-300 text-red-800';
      case 'medium':
        return 'bg-orange-50 border-orange-300 text-orange-800';
      case 'low':
        return 'bg-yellow-50 border-yellow-300 text-yellow-800';
      default:
        return 'bg-gray-50 border-gray-300 text-gray-800';
    }
  };

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case 'high':
        return 'bg-red-600 text-white';
      case 'medium':
        return 'bg-orange-500 text-white';
      case 'low':
        return 'bg-yellow-500 text-white';
      default:
        return 'bg-gray-500 text-white';
    }
  };

  const sortedWeaknesses = [...weaknesses].sort((a, b) => {
    const severityOrder = { high: 0, medium: 1, low: 2 };
    return severityOrder[a.severity] - severityOrder[b.severity];
  });

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-center justify-between p-4 bg-red-50 hover:bg-red-100 transition"
      >
        <div className="flex items-center gap-3">
          <AlertTriangle className="w-5 h-5 text-red-600" />
          <h3 className="font-semibold text-gray-900">
            Control Weaknesses ({weaknesses.length})
          </h3>
        </div>
        {isExpanded ? (
          <ChevronDown className="w-5 h-5 text-gray-600" />
        ) : (
          <ChevronRight className="w-5 h-5 text-gray-600" />
        )}
      </button>

      {isExpanded && (
        <div className="p-4 space-y-3 max-h-96 overflow-y-auto">
          {weaknesses.length === 0 ? (
            <p className="text-sm text-gray-500 text-center py-4">
              No weaknesses identified
            </p>
          ) : (
            sortedWeaknesses.map((weakness) => (
              <div
                key={weakness.id}
                className={`p-4 rounded-lg border-2 ${getSeverityColor(weakness.severity)}`}
              >
                <div className="flex items-start justify-between gap-3 mb-2">
                  <p className="font-medium text-sm">{weakness.description}</p>
                  <span
                    className={`px-2 py-1 rounded text-xs font-semibold uppercase whitespace-nowrap ${getSeverityBadge(
                      weakness.severity
                    )}`}
                  >
                    {weakness.severity}
                  </span>
                </div>
                <div className="mt-3 pt-3 border-t border-current border-opacity-20">
                  <p className="text-xs font-medium mb-1">Recommendation:</p>
                  <p className="text-xs">{weakness.recommendation}</p>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}
